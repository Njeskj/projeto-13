<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	 <meta charset="UTF-8">
	 <style>
	 	body{
	 		background-color: grey;
	 	}
	 </style>
      
</head>
<body>

	<section>
		
		<div class="loginsection" style="">
			<center>
				<h2>Login</h2>

			
				<form action="actionpage.php?login" method="POST">
			   			 <input type="text" class="form-control" placeholder="Username" name="username"><br>
			   			 <input type="password" class="form-control" placeholder="Password" name="password"><br> <br>
			 			 <button type="submit">Login</button>
		
			</form> 
<br>
			<a href="signup.php">Signup</a>
			</center>
			
		 
			
		</div>
		
			
	
	</section>
</body>

</html>